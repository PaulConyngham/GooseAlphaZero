from alphazero_mcp import mcp

def main():
    mcp.run()

if __name__ == "__main__":
    mcp.run()
